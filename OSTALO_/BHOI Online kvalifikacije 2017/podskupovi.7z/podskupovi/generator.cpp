#include <random>
#include <iostream>
#include <string>
#include <cstring>
#include <sstream>
#include <fstream>

template<class T> std::string to_string(const T &n)
{
    std::ostringstream stm;
    stm << n;
    return stm.str();
}

std::vector<int> subtasks = { 10, 10 };

int main()
{
    std::random_device rd;  //Will be used to obtain a seed for the random number engine
    std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
    std::uniform_int_distribution<> dis(-20000000, 20000000);
    std::uniform_int_distribution<> range_dis(-500000000, 500000000);
    std::uniform_int_distribution<> range_small(-5000000, 5000000);

    int subtask = 1, test_case = 0;

    for (auto x : subtasks)
    {
        while (x--)
        {
            std::ofstream xout("in" + to_string(test_case++) + ".txt");
            long long a, b;
            if (subtask == 1)
            {
                a = range_small(gen);
                b = range_small(gen);
            }
            else
            {
                a = range_dis(gen);
                b = range_dis(gen);
            }
            int cnt = subtask == 1 ? 10 : 34;
            xout << cnt << ' ' << std::min(a, b) << ' ' << std::max(a, b) << '\n';
            for (int i = 0; i < cnt; i++)
                xout << dis(gen) << ' ';
        }
        subtask++;
    }

    return 0;
}

