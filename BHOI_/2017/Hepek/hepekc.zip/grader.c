#include <stdio.h>
#include <stdlib.h>
long long n, *a;
int k;

int upit(long long x, long long L, long long R) {
	if(L > R) return 0;
	if(L < 1 || L > n || R < 1 || R > n) return 0;
	for(long long i = L; i <= R; ++i) {
		if(x < a[i]) return 0;
	}
	return 1;
}

void DetekcijaAnomalija(long long n, int k, long long *anomalije) {
	//ovdje pisete svoj kod
}

int main() {
	scanf("%lld %d",&n,&k);
	a = (long long*)malloc(sizeof(long long) * (n+1));
	for(int i = 1; i <= n; ++i) scanf("%lld",&a[i]);
	long long *anomalije = (long long*)calloc(sizeof(long long) * k, sizeof(long long));
	DetekcijaAnomalija(n,k,anomalije);
	int flag = 1;
	for(int i = 0; i < k && flag; ++i) {
		long long x = a[anomalije[i]];
		for(int j = 1; j <= n && flag; ++j)
			if(x < a[j]) flag = 0;
		a[anomalije[i]] = -1;
	}
	if(flag) printf("Pronasli ste ispravno rjesenje!\n");
	else printf("Niste pronasli ispravno rjesenje!");
	return 0;
}
