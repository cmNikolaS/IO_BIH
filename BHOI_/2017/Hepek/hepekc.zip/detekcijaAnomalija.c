//vasi includeovi ili using deklarative

extern int upit(long long, long long, long long);

void DetekcijaAnomalija(long long n, int k, long long *anomalije) {
	//vasa logika rjesenja
}
